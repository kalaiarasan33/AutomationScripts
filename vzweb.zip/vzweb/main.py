from winrm.protocol import Protocol
import paramiko
from flask import *  
import boto3
from collections import defaultdict

session = boto3.Session(    aws_access_key_id="AKIAQZKPRYLCT5RFXRBA",    aws_secret_access_key="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")

app = Flask(__name__) 



@app.route('/')  
def adhoc(): 
      return render_template('adhoc.html')

@app.route('/server',methods = ['POST'])           

def server():
      os=request.form['os']
      host_s=request.form['host']
      host_l=list(host_s.split(","))  
      cmd=request.form['cmd']
      if os =="linux":
            li_output={}
            for host in host_l:
                  #o="***** hostname : {}*****,{}".format(host,)
                  error=["Not able to connect please check "]
                  try:
                        li_output[host]= li(host,cmd)
                  except:
                        li_output[host]= error
                            
            return  render_template("message.html",output=li_output)    
      elif os =="windows":
            wi_output={}
            for host in host_l:
                  #o="***** hostname : {}*****,{}".format(host,win(host,cmd))
                  error=["Not able to connect please check "]
                  try:
                        wi_output[host]= win(host,cmd)
                  except:
                        wi_output[host]=error
                        
            return  render_template("message.html",output=wi_output)  
      
@app.route('/elb')

def elb():
      elb_output=elb_hname()
      return  render_template("Elb.html",output=elb_output)



#############################     Funtions           #####################################################################   
          
def li(host,cmd):
      username = "kalai"
      passw="kalai"
      ssh = paramiko.SSHClient()
      ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
      ssh.connect(hostname=host, username=username , password=passw)
      stdin, stdout, stderr = ssh.exec_command(cmd)
      outlines = stdout.readlines()
      res ="".join(outlines)
      resp=[x.strip() for x in res.split('\n')]
      return resp

def win(host,cmd):
      p = Protocol(
      endpoint="https://{}:5986/wsman".format(host),
      transport='ntlm',
      username=r'Administrator',
      password=r"Windows machine username",
      server_cert_validation='ignore')
      shell_id = p.open_shell()
      command_id = p.run_command(shell_id, cmd)
      std_out, std_err, status_code = p.get_command_output(shell_id, command_id)
      outlines = std_out.decode("utf-8")
      res ="".join(outlines)
      resp=[x.strip() for x in res.split('\n')]
      p.cleanup_command(shell_id, command_id)
      p.close_shell(shell_id)
      return resp



def des_elb():
    elb = session.client('elb')
    response= elb.describe_load_balancers()['LoadBalancerDescriptions']
    elb={}
    for x in response:
        temp=[]
        for y in x['Instances']:
            temp.append(y["InstanceId"])
        elb[x['LoadBalancerName']]=temp
    return(elb)

def instance_name(elb):
    ec2 = session.client('ec2')
    tmp=[]
    for key,v in elb.items():            
            for k in range(0,len(elb[key])):

                for x in  ec2.describe_instances( InstanceIds=[elb[key][k]])['Reservations']:
                        for inst in x['Instances']:
                            #print(inst['InstanceId'])
                            tag_len=len(inst['Tags'])                       
                            for r in range(0,tag_len):
                                if inst['Tags'][r]['Key'] == 'Name':
                                    ins_name=inst['Tags'][r]['Value']
                                    temp={key:ins_name}
                                    tmp.append(temp)                                    
    return tmp

def elb_hname():
    d=defaultdict(list)                               
    li=instance_name(des_elb())
    for l in li:
        for k,v in l.items():
            d[k].append(v)
    return dict(d)


if __name__ == '__main__':  
   app.run(debug = True)