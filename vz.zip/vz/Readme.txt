Install python 3.x


Commands to install python modules
pip install pywinrm==0.2.2
pip install paramiko
pip install Flask
pip install boto3





To perform command in windows, need ntlm connection 
# from powershell:
Invoke-Expression ((New-Object System.Net.Webclient).DownloadString('https://raw.githubusercontent.com/ansible/ansible/devel/examples/scripts/ConfigureRemotingForAnsible.ps1'))


To access aws , we need aws accesskey and secret key 