import boto3
from collections import defaultdict


def des_elb():
    elb = boto3.client('elb')
    response= elb.describe_load_balancers()['LoadBalancerDescriptions']
    elb={}
    for x in response:
        temp=[]
        for y in x['Instances']:
            temp.append(y["InstanceId"])
        elb[x['LoadBalancerName']]=temp
    return(elb)

def instance_name(elb):
    ec2 = boto3.client('ec2')
    tmp=[]
    for key,v in elb.items():            
            for k in range(0,len(elb[key])):

                for x in  ec2.describe_instances( InstanceIds=[elb[key][k]])['Reservations']:
                        for inst in x['Instances']:
                            #print(inst['InstanceId'])
                            tag_len=len(inst['Tags'])                       
                            for r in range(0,tag_len):
                                if inst['Tags'][r]['Key'] == 'Name':
                                    ins_name=inst['Tags'][r]['Value']
                                    temp={key:ins_name}
                                    tmp.append(temp)                                    
    return tmp

def elb_hname():
    d=defaultdict(list)                               
    li=instance_name(des_elb())
    for l in li:
        for k,v in l.items():
            d[k].append(v)
    return dict(d)

print(elb_hname())