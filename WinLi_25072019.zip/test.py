def k():
    u="a"
    y="b"
    return b
def kk(u):
    print(u)
    return

kk(k())
