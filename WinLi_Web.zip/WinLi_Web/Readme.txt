D:\WinLi_Web>Scripts\activate

(WinLi_Web) D:\WinLi_Web>python main.py
 * Serving Flask app "main" (lazy loading)
 * Environment: production
   WARNING: This is a development server. Do not use it in a production deployme
nt.
   Use a production WSGI server instead.
 * Debug mode: on
 * Restarting with stat
 * Debugger is active!
 * Debugger PIN: 108-215-355
 * Running on http://127.0.0.1:5000/ (Press CTRL+C to quit)
